-- MySQL dump 10.13  Distrib 5.1.49, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: hacking
-- ------------------------------------------------------
-- Server version	5.1.49-1ubuntu8.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_425ae3c4` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_message`
--

DROP TABLE IF EXISTS `auth_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_message_403f60f` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_message`
--

LOCK TABLES `auth_message` WRITE;
/*!40000 ALTER TABLE `auth_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_1bb8f392` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add message',4,'add_message'),(11,'Can change message',4,'change_message'),(12,'Can delete message',4,'delete_message'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add site',7,'add_site'),(20,'Can change site',7,'change_site'),(21,'Can delete site',7,'delete_site'),(22,'Can add log entry',8,'add_logentry'),(23,'Can change log entry',8,'change_logentry'),(24,'Can delete log entry',8,'delete_logentry'),(25,'Can add forum',9,'add_forum'),(26,'Can change forum',9,'change_forum'),(27,'Can delete forum',9,'delete_forum'),(28,'Can add Thread',10,'add_thread'),(29,'Can change Thread',10,'change_thread'),(30,'Can delete Thread',10,'delete_thread'),(31,'Can add Post',11,'add_post'),(32,'Can change Post',11,'change_post'),(33,'Can delete Post',11,'delete_post'),(37,'Can add notice',13,'add_notice'),(38,'Can change notice',13,'change_notice'),(39,'Can delete notice',13,'delete_notice'),(40,'Can add person',14,'add_person'),(41,'Can change person',14,'change_person'),(42,'Can delete person',14,'delete_person'),(43,'Can add challenge',15,'add_challenge'),(44,'Can change challenge',15,'change_challenge'),(45,'Can delete challenge',15,'delete_challenge'),(46,'Can add trophy',16,'add_trophy'),(47,'Can change trophy',16,'change_trophy'),(48,'Can delete trophy',16,'delete_trophy'),(49,'Can add team profile',17,'add_teamprofile'),(50,'Can change team profile',17,'change_teamprofile'),(51,'Can delete team profile',17,'delete_teamprofile'),(52,'Can add submit log',18,'add_submitlog'),(53,'Can change submit log',18,'change_submitlog'),(54,'Can delete submit log',18,'delete_submitlog'),(55,'Can add Article',19,'add_article'),(56,'Can change Article',19,'change_article'),(57,'Can delete Article',19,'delete_article'),(58,'Can add Change set',20,'add_changeset'),(59,'Can change Change set',20,'change_changeset'),(60,'Can delete Change set',20,'delete_changeset'),(61,'Can add captcha store',21,'add_captchastore'),(62,'Can change captcha store',21,'change_captchastore'),(63,'Can delete captcha store',21,'delete_captchastore'),(64,'Can add flat page',22,'add_flatpage'),(65,'Can change flat page',22,'change_flatpage'),(66,'Can delete flat page',22,'delete_flatpage'),(67,'Can add pic',23,'add_pic'),(68,'Can change pic',23,'change_pic'),(69,'Can delete pic',23,'delete_pic'),(70,'Can add tarball',24,'add_tarball'),(71,'Can change tarball',24,'change_tarball'),(72,'Can delete tarball',24,'delete_tarball'),(73,'Can add choice challenge',25,'add_choicechallenge'),(74,'Can change choice challenge',25,'change_choicechallenge'),(75,'Can delete choice challenge',25,'delete_choicechallenge');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'root','','','oyea9le@gmail.com','sha1$c9f5e$d4138e0b858a84f8d04a8ff821cc5638cd3af96c',1,1,1,'2011-01-13 06:28:21','2011-01-09 16:48:53'),(2,'good','','','good@oyea9le.com','sha1$93d0e$5f00b8f6616375d1fa2f2ab630edbf5ca70d3c97',0,1,0,'2011-01-12 18:18:25','2011-01-09 21:12:27'),(3,'renewjoy','','','joy@gmail.com','sha1$4e557$d35a46799f918efda6d8cd331e8831e451c57476',0,1,0,'2011-01-11 11:33:01','2011-01-10 21:27:50'),(4,'one','','','one@oyea9le.com','sha1$7e8a0$d6a6b5a087df216a3ef9cb528744817f315027c9',0,0,0,'2011-01-11 11:20:38','2011-01-11 11:20:38');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_403f60f` (`user_id`),
  KEY `auth_user_groups_425ae3c4` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_403f60f` (`user_id`),
  KEY `auth_user_user_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `captcha_captchastore`
--

DROP TABLE IF EXISTS `captcha_captchastore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `captcha_captchastore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge` varchar(32) NOT NULL,
  `response` varchar(32) NOT NULL,
  `hashkey` varchar(40) NOT NULL,
  `expiration` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hashkey` (`hashkey`)
) ENGINE=MyISAM AUTO_INCREMENT=343 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `captcha_captchastore`
--

LOCK TABLES `captcha_captchastore` WRITE;
/*!40000 ALTER TABLE `captcha_captchastore` DISABLE KEYS */;
INSERT INTO `captcha_captchastore` VALUES (342,'10*1=','10','62b8ad1d759d97cf57b16594fb27074ab46c6e22','2011-01-13 04:07:40'),(341,'3-3=','0','bdba10d93ac0ec1029f5e6344c363de27f92d62b','2011-01-13 04:07:39'),(340,'10*2=','20','92fb8c0035c24c21e5294d2a0e202f4ce9d007c9','2011-01-13 04:07:39'),(339,'8+2=','10','46cbd3888246c9a20c400d2cf2d21da87cc816fd','2011-01-13 04:07:39'),(337,'2*8=','16','b5fc8a6614462d5de7067d1beaffa7c8f83c85fd','2011-01-13 04:07:38'),(338,'2+6=','8','bda367422ad7d0688f49b156f322487d38a21c3a','2011-01-13 04:07:39'),(336,'10+8=','18','4e3097c2f2b1d67649a9850bc94247716f26872e','2011-01-13 04:07:38'),(330,'1*1=','1','8b1e87dbb2423120dd76a98427f6073432c6425e','2011-01-13 04:06:36'),(331,'9*9=','81','685e366ad70a25a5c330e99cf53e22af7036a36a','2011-01-13 04:07:35'),(332,'9-6=','3','a050dab9e334d3abc62f912ed274bcbdbcae0234','2011-01-13 04:07:36'),(333,'7-4=','3','19dee38966613bf1948c34131ce1cb92c9e734d0','2011-01-13 04:07:37'),(334,'9-8=','1','a0e59cbc5285c0547124bcdbc0dfc7f14a92d715','2011-01-13 04:07:38'),(335,'4+5=','9','a46b2213f6d79761e737faaf4cb0dcad9b338808','2011-01-13 04:07:38');
/*!40000 ALTER TABLE `captcha_captchastore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_403f60f` (`user_id`),
  KEY `django_admin_log_1bb8f392` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2011-01-09 17:43:55',1,3,'1','root',2,'Changed email.'),(2,'2011-01-09 17:44:09',1,3,'1','root',2,'Changed email.'),(3,'2011-01-10 10:41:54',1,15,'5','joy',2,'Changed answer.'),(4,'2011-01-10 15:06:17',1,22,'1','/hacking/ -- joy',1,''),(5,'2011-01-10 15:13:10',1,22,'1','/hacking/ -- joy',2,'Changed content.'),(6,'2011-01-10 15:19:46',1,22,'1','/hacking/1/ -- joy',2,'Changed url.'),(7,'2011-01-10 15:30:25',1,15,'1','欧阳峰',2,'Changed is_shown, url and url_bak.'),(8,'2011-01-10 16:03:10',1,23,'1','Pic object',1,''),(9,'2011-01-10 16:04:25',1,22,'2','/hacking/joy/ -- joytest',1,''),(10,'2011-01-10 16:04:55',1,15,'2','黄药师',2,'Changed is_shown, url and url_bak.'),(11,'2011-01-10 16:06:30',1,22,'2','/hacking/joy/ -- joytest',2,'Changed content.'),(12,'2011-01-10 16:07:02',1,22,'2','/hacking/joy/ -- joytest',2,'Changed content.'),(13,'2011-01-11 17:31:05',1,25,'1','ChoiceChallenge object',1,''),(14,'2011-01-11 17:43:37',1,25,'1','ChoiceChallenge object',2,'No fields changed.'),(15,'2011-01-11 17:57:40',1,25,'1','ChoiceChallenge object',1,''),(16,'2011-01-12 13:31:31',1,17,'1','Team information for team root',1,''),(17,'2011-01-12 16:18:51',1,13,'1','第一期参考答案(不断更新中)',1,''),(18,'2011-01-12 16:19:18',1,13,'1','第一期参考答案(不断更新中)',2,'No fields changed.'),(19,'2011-01-12 16:19:31',1,13,'1','第一期参考答案(不断更新中)',2,'Changed classify.'),(20,'2011-01-12 16:46:24',1,13,'2','团队注册注意事项',1,''),(21,'2011-01-12 16:50:19',1,13,'2','团队注册注意事项',2,'Changed is_shown.'),(22,'2011-01-12 16:50:35',1,13,'2','团队注册注意事项',2,'Changed is_shown.'),(23,'2011-01-12 16:51:07',1,13,'2','团队注册注意事项',2,'Changed is_shown.'),(24,'2011-01-12 16:53:04',1,13,'2','团队注册注意事项',2,'Changed is_shown.'),(25,'2011-01-12 17:00:57',1,13,'2','团队注册注意事项',2,'No fields changed.'),(26,'2011-01-12 18:28:14',1,14,'4','张三丰',1,''),(27,'2011-01-12 18:29:49',1,15,'6','张三丰',1,''),(28,'2011-01-12 18:30:45',1,14,'4','张三丰',2,'Changed brief.'),(29,'2011-01-12 18:36:19',1,14,'5','达摩',1,''),(30,'2011-01-12 18:37:31',1,15,'7','达摩',1,''),(31,'2011-01-12 18:51:37',1,15,'2','黄药师',2,'Changed is_shown.'),(32,'2011-01-12 18:51:54',1,15,'2','黄药师',2,'Changed is_shown.'),(33,'2011-01-12 23:36:25',1,14,'3','谢xun',2,'Changed name, grade, rp and advantages.'),(34,'2011-01-12 23:37:22',1,14,'3','谢逊',2,'Changed name.'),(35,'2011-01-12 23:46:44',1,13,'3','第二期题目已开放-渗透专题(12.09)',1,''),(36,'2011-01-12 23:47:13',1,13,'4','相关专业领域推荐书籍(不断更新）',1,''),(37,'2011-01-12 23:47:43',1,13,'5','关于注册信息的问题',1,''),(38,'2011-01-12 23:48:21',1,13,'6','竞赛规则',1,''),(39,'2011-01-12 23:48:45',1,13,'7','第一期小奖品',1,''),(40,'2011-01-12 23:49:17',1,13,'8','大赛流程',1,''),(41,'2011-01-13 05:23:40',1,13,'7','第一期小奖品',2,'Changed content.'),(42,'2011-01-13 05:23:52',1,13,'2','团队注册注意事项',2,'No fields changed.'),(43,'2011-01-13 05:26:00',1,13,'8','大赛流程',2,'No fields changed.'),(44,'2011-01-13 05:27:43',1,13,'9','test markdon',1,'');
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'permission','auth','permission'),(2,'group','auth','group'),(3,'user','auth','user'),(4,'message','auth','message'),(5,'content type','contenttypes','contenttype'),(6,'session','sessions','session'),(7,'site','sites','site'),(8,'log entry','admin','logentry'),(9,'forum','forum','forum'),(10,'Thread','forum','thread'),(11,'Post','forum','post'),(13,'notice','team','notice'),(14,'person','team','person'),(15,'challenge','team','challenge'),(16,'trophy','team','trophy'),(17,'team profile','team','teamprofile'),(18,'submit log','team','submitlog'),(19,'Article','wiki','article'),(20,'Change set','wiki','changeset'),(21,'captcha store','captcha','captchastore'),(22,'flat page','flatpages','flatpage'),(23,'pic','team','pic'),(24,'tarball','team','tarball'),(25,'choice challenge','team','choicechallenge');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_flatpage`
--

DROP TABLE IF EXISTS `django_flatpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_flatpage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(100) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  `enable_comments` tinyint(1) NOT NULL,
  `template_name` varchar(70) NOT NULL,
  `registration_required` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_flatpage_a4b49ab` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_flatpage`
--

LOCK TABLES `django_flatpage` WRITE;
/*!40000 ALTER TABLE `django_flatpage` DISABLE KEYS */;
INSERT INTO `django_flatpage` VALUES (1,'/hacking/1/','joy','<center> \r\n<table width=\"668\" border=\"0\" cellpadding=\"3\" cellspacing=\"3\" class=\"main\"> \r\n  <tr> \r\n   </tr> \r\n<tr><td> \r\n<center><h1>validate code</h1></center> \r\n<br> \r\n<div style=\"align:left;margin-left:20px;font-size: 15px;font-family:\'Courier New\'\"> \r\n<br> \r\n<font color=\'red\'>Key Words:</font> Script, bmp<br> \r\n<br><br> \r\n<div style=\"margin-left:50px;color: #00ff00\"> \r\n<a href=\"bmp.tar.bz2\">get_the_file</a><br> \r\n<br> \r\n今有一压缩包，其内图片不知几许。<br><br>\r\n请君算出所有图片上的数与其文件名之乘积，所有乘积的和为KEY。<br><br>\r\n例：<br><br>\r\n文件名为1.bmp，图片上的数为：1234<br>\r\n文件名为5.bmp，图片上的数为：5678<br>\r\n……<br>\r\n文件名为233.bmp，图片上的数为：2345<br>\r\nkey为：1234 x 1 + 5678 x 5 + ... + 2345 x 233 = ?\r\n<br><br><br>\r\n解题步骤友情提示：<br><br>\r\n1、下载压缩包。<br>\r\n2、求出乘积的和。<br>\r\n3、提交答案。<br>\r\n4、过关，获取积分。<br>\r\n</div> \r\n</table>\r\n</center>',0,'',0),(2,'/hacking/joy/','joytest','<center> \r\n<table width=\"668\" border=\"0\" cellpadding=\"3\" cellspacing=\"3\" class=\"main\"> \r\n \r\n  <tr> \r\n   </tr> \r\n<tr><td> \r\n<center><h1>第一次接触</h1></center> \r\n<br> \r\n<center><image src=\"/site_media/flatpage/pic/1.jpg\"></center> \r\n<div style=\"align:left;margin-left:20px;font-size: 15px;font-family:\'Courier New\'\"> \r\n<br> \r\n<font color=\'red\'>Key Words:</font> Asp Script<br> \r\n<br> \r\n<div style=\"margin-left:50px;color: #00ff00\"> \r\n在一个阳光明媚、春暖花开、人见人爱的日子~<br><br> \r\n一个叫 HelloWorld 的小童鞋第一次接触到了电脑这个华丽滴东东~<br><br> \r\n他玩了一个多月后就迅速地上手了~<br><br> \r\n这时他爸爸看见了~ 觉得他很有天赋学好计算机~<br><br> \r\n就想考验下他~ 于是给了他一个文件<br><br> \r\n（<font color=\'gold\'><a href=\"http://cuit.6600.org/test1/index.rar\">http://cuit.6600.org/test1/index.rar</a></font>）<br><br> \r\n让他试图去进行解密~<br><br> \r\n结果聪明的他~ 想了想，一个小时就搞定了~<br><br> \r\n<br> \r\n \r\n</div> \r\n</table><br> \r\n<br><br> \r\n</table> \r\n  <br> \r\n  <br> \r\n</center> ',0,'',0);
/*!40000 ALTER TABLE `django_flatpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_flatpage_sites`
--

DROP TABLE IF EXISTS `django_flatpage_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_flatpage_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flatpage_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flatpage_id` (`flatpage_id`,`site_id`),
  KEY `django_flatpage_sites_21210108` (`flatpage_id`),
  KEY `django_flatpage_sites_6223029` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_flatpage_sites`
--

LOCK TABLES `django_flatpage_sites` WRITE;
/*!40000 ALTER TABLE `django_flatpage_sites` DISABLE KEYS */;
INSERT INTO `django_flatpage_sites` VALUES (3,1,1),(6,2,1);
/*!40000 ALTER TABLE `django_flatpage_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('0c511dcd77875a0bd9aca3ec90f01e16','gAJ9cQEoVQ12YWxpZGF0ZV9jb2RlcQJVBDdlODJxA1USX2F1dGhfdXNlcl9iYWNrZW5kcQRVKWRq\nYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kcQVVDV9hdXRoX3VzZXJfaWRx\nBooBAnUuZTVjY2NjODIwNDIzY2M2ZjJkYWNkNmU0MzhjMmMxOTc=\n','2011-01-23 21:13:28'),('25e90413b7a755efd576c5e934c7ed8f','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5k\ncy5Nb2RlbEJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEBdS4yMmY2NmU4OGQ4OTBjMjY0MGE0\nMTNiN2EwNWI3ZTczOQ==\n','2011-01-27 06:28:21'),('bf6805a3ccf6733f2ab205d9eb911db5','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5k\ncy5Nb2RlbEJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEDdS44MjdiOWZmODhkNjcxZDhjYWI0\nYmRkNWE5ZDM0NjhjMg==\n','2011-01-25 11:33:01');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'example.com','example.com');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flat_pic`
--

DROP TABLE IF EXISTS `flat_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flat_pic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pic` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flat_pic`
--

LOCK TABLES `flat_pic` WRITE;
/*!40000 ALTER TABLE `flat_pic` DISABLE KEYS */;
INSERT INTO `flat_pic` VALUES (1,'flatpage/pic/1.jpg');
/*!40000 ALTER TABLE `flat_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flat_tarball`
--

DROP TABLE IF EXISTS `flat_tarball`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flat_tarball` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tarball` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flat_tarball`
--

LOCK TABLES `flat_tarball` WRITE;
/*!40000 ALTER TABLE `flat_tarball` DISABLE KEYS */;
/*!40000 ALTER TABLE `flat_tarball` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_forum`
--

DROP TABLE IF EXISTS `forum_forum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_forum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `description` longtext NOT NULL,
  `threads` int(11) NOT NULL,
  `posts` int(11) NOT NULL,
  `ordering` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `forum_forum_63f17a16` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_forum`
--

LOCK TABLES `forum_forum` WRITE;
/*!40000 ALTER TABLE `forum_forum` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_forum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_forum_groups`
--

DROP TABLE IF EXISTS `forum_forum_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_forum_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forum_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forum_id` (`forum_id`,`group_id`),
  KEY `forum_forum_groups_499a185a` (`forum_id`),
  KEY `forum_forum_groups_425ae3c4` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_forum_groups`
--

LOCK TABLES `forum_forum_groups` WRITE;
/*!40000 ALTER TABLE `forum_forum_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_forum_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_post`
--

DROP TABLE IF EXISTS `forum_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thread_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `body` longtext NOT NULL,
  `body_html` longtext NOT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `forum_post_65912a8a` (`thread_id`),
  KEY `forum_post_337b96ff` (`author_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_post`
--

LOCK TABLES `forum_post` WRITE;
/*!40000 ALTER TABLE `forum_post` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_thread`
--

DROP TABLE IF EXISTS `forum_thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_thread` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forum_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `sticky` tinyint(1) NOT NULL,
  `closed` tinyint(1) NOT NULL,
  `posts` int(11) NOT NULL,
  `views` int(11) NOT NULL,
  `latest_post_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `forum_thread_499a185a` (`forum_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_thread`
--

LOCK TABLES `forum_thread` WRITE;
/*!40000 ALTER TABLE `forum_thread` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_challenge`
--

DROP TABLE IF EXISTS `team_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_challenge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_shown` tinyint(1) NOT NULL,
  `author_id` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `answer` varchar(40) NOT NULL,
  `description` longtext NOT NULL,
  `prev_id` int(11) DEFAULT NULL,
  `person_id` int(11) NOT NULL,
  `difficulty_level` int(11) NOT NULL,
  `url` varchar(200) NOT NULL,
  `url_bak` varchar(200) NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`),
  KEY `team_challenge_337b96ff` (`author_id`),
  KEY `team_challenge_548b6e23` (`prev_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_challenge`
--

LOCK TABLES `team_challenge` WRITE;
/*!40000 ALTER TABLE `team_challenge` DISABLE KEYS */;
INSERT INTO `team_challenge` VALUES (1,1,1,4,'goodjob','他是一个杀人不眨眼的人。你能战胜他吗？',NULL,1,4,'http://127.0.0.1:8000/hacking/1/','http://127.0.0.1:8000/hacking/1/','2011-01-03 17:49:41'),(2,1,1,5,'123456o','这是一个很不错的想法，你认为呢？',NULL,2,5,'http://127.0.0.1:8000/hacking/joy/','http://127.0.0.1:8000/hacking/joy/','2011-01-04 21:48:55'),(5,1,1,1,'1234','sssssssssasd sasd XZasadasasd asdfas sss sadfasdf\r\n\r\njoy love you',1,3,2,'http://www.baidu.com/','http://www.baidu.com/','2011-01-07 21:55:54'),(6,1,2,8,'joytest','test for it.',5,4,8,'http://baike.baidu.com/view/9691.htm','http://baike.baidu.com/view/9691.htm','2011-01-12 18:29:49'),(7,1,1,8,'damo','to test just da.',2,5,8,'http://baike.baidu.com/view/19721.htm','http://baike.baidu.com/view/19721.htm','2011-01-12 18:37:31');
/*!40000 ALTER TABLE `team_challenge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_choicechallenge`
--

DROP TABLE IF EXISTS `team_choicechallenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_choicechallenge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `score` int(11) NOT NULL,
  `answer` varchar(1) NOT NULL,
  `content` longtext NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_choicechallenge`
--

LOCK TABLES `team_choicechallenge` WRITE;
/*!40000 ALTER TABLE `team_choicechallenge` DISABLE KEYS */;
INSERT INTO `team_choicechallenge` VALUES (1,1,'A','在类定义的外部，可以被访问的成员有（   ）\r\n\r\nA) 所有类成员              B) private或protected的类成员\r\n\r\nC) public的类成员           D) public或private的类成员','2011-01-11 17:57:40');
/*!40000 ALTER TABLE `team_choicechallenge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_notice`
--

DROP TABLE IF EXISTS `team_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_shown` tinyint(1) NOT NULL,
  `classify` varchar(40) NOT NULL,
  `title` varchar(40) NOT NULL,
  `emg_level` varchar(40) NOT NULL,
  `author_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `pub_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `team_notice_337b96ff` (`author_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_notice`
--

LOCK TABLES `team_notice` WRITE;
/*!40000 ALTER TABLE `team_notice` DISABLE KEYS */;
INSERT INTO `team_notice` VALUES (1,1,'发奖事项','第一期参考答案(不断更新中)','5',1,'低年级组参考答案地址\r\n\r\nhttp://tech.cuit.edu.cn/forum/thread-22014-1-1.html\r\n\r\n高年级组参考答案地址\r\n\r\nhttp://tech.cuit.edu.cn/forum/thread-22015-1-1.html','2011-01-12 16:18:51'),(2,1,'挑战公告','团队注册注意事项','3',3,'所有队伍注册请以 真实姓名和学号 进行注册，否则注册期一到，一律按无效队伍处理。\r\n\r\n外界Hacker想看下题给予建议的，请直接联系 CasperKid，由其统一分配临时账号。\r\n\r\nCasperKid\'s Email: (casperkid.syclover@gmail.com)','2011-01-12 16:46:24'),(3,1,'注意事项','第二期题目已开放-渗透专题(12.09)','32',2,'第二期为渗透测试专题~\r\n\r\n第一期题目平均难度偏难了些~\r\n\r\n让大家做纠结了~ 不好意思~\r\n\r\n第二期的难度降低了比较多~\r\n\r\n主要以引导为主~ 题目都不难~\r\n\r\n会一点一点引导大家如何去进行渗透测试~\r\n\r\n最后完成对一个网站的渗透~\r\n\r\n希望大家能从中有所收获~\r\n\r\n有问题可以在 CUIT技术网 和 平台留言板反馈~','2011-01-12 23:46:44'),(4,1,'发奖事项','相关专业领域推荐书籍(不断更新）','2',1,'\r\n01. 程序设计 (算法编程 有趣的程序编程 病毒/木马编程等)\r\n02. 逆向分析 (软件破解 病毒/木马分析 还原源代码等)\r\n03. 漏洞挖掘以及利用 (利用综合能力挖掘/分析/利用漏洞等)\r\n04. 社会工程学 (通过社交行为获取敏感信息等)\r\n05. 模糊测试 (模糊测试软件漏洞等)\r\n06. 渗透测试 (渗透入侵服务器等)\r\n07. 智能卡 (RFID射频卡)\r\n08. 脚本分析 (Asp Php Jsp Aspx Python Perl Ruby等)\r\n09. 人工智能 (基于规则的专家系统 基于模糊的专家系统等)\r\n10. 编译原理 (词法扫描器编写 语法扫描器编写)\r\n11. 计算机网络 (网络工程 tcp/ip等)\r\n12. 底层分析 (驱动分析 内核分析等)\r\n13. 无线网络破解 (WEP破解 WPA破解等)\r\n14. 电子硬件制作类 (嵌入式 硬件小玩意制作等)\r\n15. Linux系统的使用 (Backtrack4 CentOS等)','2011-01-12 23:47:13'),(5,1,'挑战公告','关于注册信息的问题','3',2,'\r\n注册信息里面有违反相关规定的，已经被修改哈。\r\n\r\n\r\n\r\n大家是大学生哈，是有文化的。\r\n\r\n\r\n\r\n如果修改了你的登录名，请去“积分排名”看看。\r\n\r\n\r\n\r\n为此给你带来的不便，请谅解。','2011-01-12 23:47:43'),(6,1,'挑战公告','竞赛规则','4',2,'\r\n所有题均按照题目自主写出一份详细的 分析报告，不必要的话不用太多，体现出流程、核心即可，尤其是 比较好的见解和一些新想法 可以获得额外加分。\r\n\r\n分析报告文件名格式  -  <团队名> + <队长姓名> + <学号> + <题名> .rar\r\n\r\n分析报告发送至 指定的邮箱，出题者会根据出题组商讨的评分标准来进行批改，然后评分，比赛完一周内 会给每支队伍增加上分数，以及队伍的积分排名。','2011-01-12 23:48:21'),(7,1,'挑战公告','第一期小奖品','2',3,'第一期奖品为 全球topic 20 hacker movie + 额外hacker movie\r\n\r\n总共差不多25部左右黑客电影，大概有30G左右。\r\n\r\n(PS: 下载了我3-4个月的时间啊~  TAT~)','2011-01-12 23:48:45'),(8,1,'挑战公告','大赛流程','23',1,'主办者 :   CUIT网络安全技术团队三叶草小组 （Syclover）\r\n参赛对象 : CUIT所有在校计算机技术爱好者\r\n竞赛时间 : （每个月一期，暂定4期为一轮，以此衔接网络攻防大赛）\r\n            第一期为11月7日- 11月30日\r\n            第二期为12月7日- 12月30日\r\n            第三期为02月7日- 02月28日\r\n            第四期为03月7日- 03月30日 （决赛期，前三期积分前10名能参加）\r\n            校内网络攻防大赛04月10日 – 04月30日 （可能临时有变动）\r\n            省级网络攻防大赛05月15日 – 05月30日 （可能临时有变动）\r\n竞赛制度 : 采用积分累计制\r\n            每一期仅公布 前15名 的积分成绩 ( 方便参赛选手定位自己名次 )\r\n            最后一期（第四期）为 决赛期\r\n            仅前三期积分 前10名 进入最后的决赛\r\n比赛平台 : http://hack.myclover.org (11月7日晚上10点 正式开放) \r\n           最新详情请关注 CUIT技术论坛 <黑客大挑战> 专区 \r\n           http://tech.cuit.edu.cn\r\n\r\n竞赛奖励 : 每个月出一次挑战题目，挑战成功的 前3名 给予一定小奖励\r\n\r\n           最后的决赛期由学院颁发 证书和其他额外奖励。\r\n\r\n\r\n挑战报名:\r\n1. 报名条件 : 凡我校学生均可报名参加，没有系别、专业和本专科的限制。 \r\n2. 报名方法 : 参赛的队伍必须在比赛平台上进行注册，注册时间从 11月7日至11月15日。\r\n3. 题目分级 : 题目采用分年级竞赛，分为 两个竞赛组 - 低年级组（大一组）、高年级组（大二、三、四组） \r\n4. 组队方式 : 组队方式：参赛学生由 <各自竞赛组> 自由组成参赛队，每期题目大概仅为 5-6 道题左右，所以为了保证引导效果，每队仅 1-2 人组队，且参赛队队员不受系别和专业的限制，自选队长一名。\r\n\r\n要求说明: \r\n所有题都要求提交完整的分析报告，你如何完成的、怎么想的、怎么思考的以及有什么疑问或不解，还有对出题组有什么建议等。\r\n\r\n评分标准:\r\n由出题者给出评分标准，例如一份分析报告，分析到何种程度和哪些方面给予多少分，以此来作为参考。\r\n\r\n答辩:\r\n竞赛结束后一个星期内进行答辩，答辩团队由出题者和老师组成。具体答辩时间地点，请留意论坛交流区。','2011-01-12 23:49:17'),(9,1,'挑战公告','test markdon','32',2,'<font color=\"red\"> good</font>','2011-01-13 05:27:43');
/*!40000 ALTER TABLE `team_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_person`
--

DROP TABLE IF EXISTS `team_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `grade` int(11) NOT NULL,
  `rp` varchar(30) NOT NULL,
  `advantages` varchar(80) NOT NULL,
  `brief` longtext NOT NULL,
  `pic` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_person`
--

LOCK TABLES `team_person` WRITE;
/*!40000 ALTER TABLE `team_person` DISABLE KEYS */;
INSERT INTO `team_person` VALUES (1,'欧阳峰',4,'恶人','西毒杖法','他确实是一个大恶人。','images/person/ayf.jpg'),(2,'黄药师',5,'亦正亦斜','弹指神通；玉箫棍法','黄药师，外号“东邪”，“天下五绝”之一。黄药师“正中带有七分邪，邪中带有三分正”的人物，是桃花岛的岛主，亦是桃花岛派创始人。','images/person/hys.png'),(3,'谢逊',5,'亦正亦斜','七伤拳','adfassssssssssss','images/person/tld'),(4,'张三丰',8,'正派','太极','张三丰，本名通，字君宝，元季儒者、道士。善书画，工诗词，中统元年，汉族，辽宁人。\r\n\r\n曾举茂才异等，任中山博陵令。自称张天师后裔，为武当派开山祖师。明英宗赐号“通微显化真人”；\r\n\r\n明宪宗特封号为“韬光尚志真仙”；明世宗赠封他为“清虚元妙真君”。','images/person/张三丰.jpg'),(5,'达摩',1,'正派','七十二绝技','达摩，全称菩提达摩，意译为觉法。南天竺人，生卒年月不详，婆罗门种姓，自称佛传禅宗第二十八祖，为中国禅宗的始祖，故中国的禅宗又称达摩宗，是《洗髓经》、《易筋经》的撰写者。达摩被尊称为“东土第一代祖师”、“达摩祖师”。与宝志禅师、傅大士合称梁代三大士。于中国南朝梁武帝时期航海到广州。梁武帝信佛。达摩至南朝都城建业会梁武帝，面谈不契，遂一苇渡江，北上北魏都城洛阳，后卓锡嵩山少林寺，面壁九年，传衣钵于慧可。后出禹门游化终身。','images/person/达摩.jpg');
/*!40000 ALTER TABLE `team_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_submitlog`
--

DROP TABLE IF EXISTS `team_submitlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_submitlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `ip` char(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `challenge_id` (`challenge_id`,`user_id`),
  KEY `team_submitlog_22741432` (`challenge_id`),
  KEY `team_submitlog_403f60f` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_submitlog`
--

LOCK TABLES `team_submitlog` WRITE;
/*!40000 ALTER TABLE `team_submitlog` DISABLE KEYS */;
INSERT INTO `team_submitlog` VALUES (10,1,3,'2011-01-13 01:43:01','127.0.0.1'),(11,1,1,'2011-01-13 01:44:03','127.0.0.1');
/*!40000 ALTER TABLE `team_submitlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_teamprofile`
--

DROP TABLE IF EXISTS `team_teamprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_teamprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `team_name` varchar(50) NOT NULL,
  `leader_name` varchar(50) NOT NULL,
  `leader_sn` varchar(10) NOT NULL,
  `mem1_name` varchar(50) NOT NULL,
  `mem1_sn` varchar(10) NOT NULL,
  `mem2_name` varchar(50) NOT NULL,
  `mem2_sn` varchar(10) NOT NULL,
  `mem3_name` varchar(50) NOT NULL,
  `mem3_sn` varchar(10) NOT NULL,
  `university` varchar(50) NOT NULL,
  `college` varchar(50) NOT NULL,
  `rank` int(11) NOT NULL,
  `finished` varchar(200) NOT NULL,
  `last_submit` datetime DEFAULT NULL,
  `activation_key` varchar(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_teamprofile`
--

LOCK TABLES `team_teamprofile` WRITE;
/*!40000 ALTER TABLE `team_teamprofile` DISABLE KEYS */;
INSERT INTO `team_teamprofile` VALUES (1,1,'joytest','','','','','','','','','外界Hacker','网络工程学院',4,'1','2011-01-13 01:44:03','123456'),(2,3,'攻防测试','renewjoy','2007122048','joy1','2007122049','joy2','2007122050','joy3','2007122051','成都信息工程学院','网络工程学院',4,'1','2011-01-13 01:43:01','ALREADY_ACTIVATED'),(3,2,'攻防团队','renewjoy','2007122048','','','','','','','成都信息工程学院','网络工程学院',0,'',NULL,'ALREADY_ACTIVATED');
/*!40000 ALTER TABLE `team_teamprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_trophy`
--

DROP TABLE IF EXISTS `team_trophy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_trophy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `grade` int(11) NOT NULL,
  `classify` int(11) NOT NULL,
  `brief` longtext NOT NULL,
  `pic` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_trophy`
--

LOCK TABLES `team_trophy` WRITE;
/*!40000 ALTER TABLE `team_trophy` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_trophy` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-01-13  6:29:10
