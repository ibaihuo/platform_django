#!/usr/bin/env python
#-*- coding:utf-8 -*-

from django.conf.urls.defaults import *

from django.contrib import admin
from django.contrib.auth.views import login,logout
from django.views.generic.simple import direct_to_template

admin.autodiscover()

urlpatterns = patterns('',
     # Why this is for development?
    (r'^captcha/', include('captcha.urls')),
    (r'^forum/', include('forum.urls')),
    (r'^accounts/', include('registration.urls')),
    (r'^site_media/(?P<path>.*)$', 'django.views.static.serve', {'document_root': '/home/joy/Django/hacking/site_media'}),

    (r'^$', 'team.views.notice'),
    (r'^notice/(\d+)/$', 'team.views.notice_detail'),
    (r'^contactme/$', 'home.contactme'),

    # account
#     (r'^accounts/register/$', 'team.views.register'),
#     (r'^accounts/login/$',login),
#     (r'^accounts/logout/$',logout),
     (r'^accounts/profile/$', 'team.views.profile'),
     (r'^accounts/profile/edit/$', 'team.views.profile_edit'),      
#     (r'^accounts/change-password/$', 'team.views.change_password'),                       

    # Challenge
    url(r'^challenge/$', 'team.views.challenge',name="challenge_index"),
    url(r'^challenge/(\d+)/$','team.views.challenge_detail'),
    url(r'^challenge/(\d+)/submit$','team.views.submit_answer'),
    url(r'^challenge/choice/$','team.views.challenge_choice'),                       
                      
    (r'^rank/$','team.views.rank'),
    (r'^rank/report/$','team.views.rank_report'),
    (r'^check_code/$','pic.check_code'),

    (r'^about/$',direct_to_template,{'template':'about.html'}),

    (r'^admin/', include(admin.site.urls)),
)
