-- MySQL dump 10.13  Distrib 5.1.49, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: hacking
-- ------------------------------------------------------
-- Server version	5.1.49-1ubuntu8.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team_challenge`
--

DROP TABLE IF EXISTS `team_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_challenge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_shown` varchar(6) NOT NULL,
  `author_id` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `answer` varchar(40) NOT NULL,
  `description` longtext NOT NULL,
  `prev_id` int(11) DEFAULT NULL,
  `person_id` int(11) NOT NULL,
  `difficulty_level` int(11) NOT NULL,
  `url` varchar(200) NOT NULL,
  `url_bak` varchar(200) NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`),
  KEY `team_challenge_337b96ff` (`author_id`),
  KEY `team_challenge_548b6e23` (`prev_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_challenge`
--

LOCK TABLES `team_challenge` WRITE;
/*!40000 ALTER TABLE `team_challenge` DISABLE KEYS */;
INSERT INTO `team_challenge` VALUES (1,'1',1,4,'goodjob','他是一个杀人不眨眼的人。你能战胜他吗？',NULL,1,4,'http://www.baidu.com/','http://www.baidu.com/','2011-01-03 17:49:41'),(2,'1',1,5,'123456o','这是一个很不错的想法，你认为呢？',NULL,2,5,'http://www.baidu.com/','http://www.baidu.com/','2011-01-04 21:48:55'),(5,'Y',1,1,'sssseeg','sssssssssasd sasd XZasadasasd asdfas sss sadfasdf\r\n\r\njoy love you',1,3,2,'http://www.baidu.com/','http://www.baidu.com/','2011-01-07 21:55:54');
/*!40000 ALTER TABLE `team_challenge` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-01-09 16:44:45
