-- MySQL dump 10.13  Distrib 5.1.49, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: hacking
-- ------------------------------------------------------
-- Server version	5.1.49-1ubuntu8.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_425ae3c4` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=175 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
INSERT INTO `auth_group_permissions` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,1,10),(8,1,11),(9,1,12),(10,1,13),(11,1,14),(12,1,15),(13,1,16),(14,1,17),(15,1,18),(16,1,19),(17,1,20),(18,1,21),(19,1,25),(20,1,26),(21,1,27),(22,1,28),(23,1,29),(24,1,30),(25,1,31),(26,1,32),(27,1,33),(28,1,34),(29,1,35),(30,1,36),(31,1,37),(32,1,38),(33,1,39),(34,1,40),(35,1,41),(36,1,42),(37,1,43),(38,1,44),(39,1,45),(40,1,46),(41,1,47),(42,1,48),(43,1,49),(44,1,50),(45,1,51),(46,1,52),(47,1,53),(48,1,54),(49,1,55),(50,1,56),(51,1,57),(52,1,58),(53,1,59),(54,1,60),(55,1,61),(56,1,62),(57,1,63),(58,1,67),(59,1,68),(60,1,69),(61,1,70),(62,1,71),(63,1,72),(64,2,1),(65,2,2),(66,2,3),(67,2,4),(68,2,5),(69,2,6),(70,2,7),(71,2,8),(72,2,9),(73,2,10),(74,2,11),(75,2,12),(76,2,13),(77,2,14),(78,2,15),(79,2,16),(80,2,17),(81,2,18),(82,2,19),(83,2,20),(84,2,21),(85,2,22),(86,2,23),(87,2,24),(88,2,25),(89,2,26),(90,2,27),(91,2,28),(92,2,29),(93,2,30),(94,2,31),(95,2,32),(96,2,33),(97,2,34),(98,2,35),(99,2,36),(100,2,37),(101,2,38),(102,2,39),(103,2,40),(104,2,41),(105,2,42),(106,2,43),(107,2,44),(108,2,45),(109,2,46),(110,2,47),(111,2,48),(112,2,49),(113,2,50),(114,2,51),(115,2,52),(116,2,53),(117,2,54),(118,2,55),(119,2,56),(120,2,57),(121,2,58),(122,2,59),(123,2,60),(124,2,61),(125,2,62),(126,2,63),(127,2,67),(128,2,68),(129,2,69),(130,2,70),(131,2,71),(132,2,72),(133,3,28),(134,3,29),(135,3,30),(136,3,31),(137,3,32),(138,3,33),(139,3,34),(140,3,35),(141,3,36),(142,3,37),(143,3,38),(144,3,39),(145,3,40),(146,3,41),(147,3,42),(148,3,43),(149,3,44),(150,3,45),(151,3,46),(152,3,47),(153,3,48),(154,3,49),(155,3,50),(156,3,51),(157,3,52),(158,3,53),(159,3,54),(160,3,55),(161,3,56),(162,3,57),(163,3,58),(164,3,59),(165,3,60),(166,3,61),(167,3,62),(168,3,63),(169,3,67),(170,3,68),(171,3,69),(172,3,70),(173,3,71),(174,3,72);
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-01-09 15:05:09
