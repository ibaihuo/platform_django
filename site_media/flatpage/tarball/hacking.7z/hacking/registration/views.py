#!/usr/bin/env python
#-*- coding:utf-8 -*-

"""
用户注册和激活账号
"""

from team.conf import settings
from django.contrib.sites.models import Site,RequestSite

from registration import signals
from registration.forms import RegistrationForm
from team.models import TeamProfile

from django.shortcuts import redirect,render_to_response
from django.template import RequestContext


def register(request,
             success_url=None,
             disallowed_url='registration_disallowed',
             template_name='registration/registration_form.html',
             extra_context=None):
    """用户注册
    """

    # 是否允许用户进行注册
    allow_regist = getattr(settings, 'REGISTRATION_OPEN', False)

    if not allow_regist:
        return redirect(disallowed_url)

    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password1']        

            if Site._meta.installed:
                site = Site.objects.get_current()
            else:
                site = RequestSite(request)


            # 创建一个未激活的用户
            new_user = TeamProfile.objects.create_inactive_user(username, email, password, site)
            # 发送信号
            # signals.user_registered.send(sender=self.__class__,
            #                              user=new_user,
            #                              request=request)

            if success_url is None:
                to, args, kwargs = ('registration_complete', (), {})
                return redirect(to, *args, **kwargs)
            else:
                return redirect(success_url)
    else:
        form = RegistrationForm()
    
    if extra_context is None:
        extra_context = {}
    context = RequestContext(request)

    for key, value in extra_context.items():
        context[key] = callable(value) and value() or value

    return render_to_response(template_name,
                              {'form': form},
                              context_instance=context)


def activate(request, activation_key,
             template_name='registration/activate.html',
             success_url=None, extra_context=None, **kwargs):
    """激活用户账号
    """

    activated = TeamProfile.objects.activate_user(activation_key)

    if activated:
        # signals.user_activated.send(sender=self.__class__,
        #                             user=activated,
        #                             request=request)
        if success_url is None:
            to, args, kwargs = ('registration_activation_complete', (), {})
            return redirect(to, *args, **kwargs)
        else:
            return redirect(success_url)

    if extra_context is None:
        extra_context = {}
    context = RequestContext(request)
    for key, value in extra_context.items():
        context[key] = callable(value) and value() or value

    return render_to_response(template_name,
                              kwargs,
                              context_instance=context)
