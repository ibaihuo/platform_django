#!/usr/bin/env python
#-*- coding:utf-8 -*-

from django import forms

class CreateThreadForm(forms.Form):
    title = forms.CharField(label="标题", max_length=100)
    body = forms.CharField(label="内容", widget=forms.Textarea(attrs={'rows':8, 'cols':160}))


class ReplyForm(forms.Form):
    body = forms.CharField(label="内容", widget=forms.Textarea(attrs={'rows':8, 'cols':160}))
