#!/usr/bin/env python
#-*- coding:utf-8 -*-

from django.contrib import admin
from forum.models import Forum, Thread, Post

class ForumAdmin(admin.ModelAdmin):
    list_display = ('title','description','ordering', '_parents_repr')
    list_filter = ('groups',)
    ordering = ['ordering', 'parent', 'title']
    prepopulated_fields = {"slug": ("title",)} # 预定义输出，即title里面输入什么, slug默认就有什么

class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ['author','thread']

class ThreadAdmin(admin.ModelAdmin):
    list_display = ('title', 'sticky', 'closed', 'forum', 'latest_post_time')
    list_filter = ('forum',)

class PostAdmin(admin.ModelAdmin):
    list_display = ('id', 'author','thread','body')


admin.site.register(Forum, ForumAdmin)
admin.site.register(Thread, ThreadAdmin)
admin.site.register(Post, PostAdmin)
