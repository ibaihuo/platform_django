from django import forms

class ContactForm(forms.Form):
    name = forms.CharField(initial='Your name')
    sender = forms.EmailField(help_text='you should give a right email that we can contact you.')
    subject = forms.CharField(max_length=100)
    message = forms.CharField(widget=forms.Textarea)
    cc_myself = forms.BooleanField(required=False)
