#!/usr/bin/env python
#-*- coding:utf-8 -*-

#from django.contrib.auth.forms import UserCreationForm
from team.conf import settings
from django.http import HttpResponseRedirect,Http404,HttpResponse
from django.shortcuts import render_to_response,get_object_or_404,redirect
from django.template import RequestContext,loader, Context
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
#from django.conf import settings

from team.forms import ChangePasswordForm,ProfileForm,SubmitForm
from team.models import ChoiceChallenge, Challenge,TeamProfile,SubmitLog,Notice
from datetime import date,datetime
from team.paginator import paginator

def notice(request):
    notices = Notice.objects.filter(is_shown=True).order_by('-pub_date')
    return render_to_response('home/notices.html',
                              paginator(request, notices, settings.NOTICE_PER_PAGE),
                              context_instance=RequestContext(request))


def notice_detail(request,notice_id):
    notice = get_object_or_404(Notice,id=notice_id)

    if not notice.is_shown:
        raise Http404

    return render_to_response('home/notices_detail.html',
                              {'notice':notice,
                               },
                              context_instance=RequestContext(request))


@login_required
def profile(request):
    current_user = request.user
    logs = SubmitLog.objects.filter(user=current_user)
    return render_to_response("profile/profile.html", {
        'the_user': current_user,
        'logs':logs,
        },
       context_instance=RequestContext(request))


@login_required
def profile_edit(request):
    """用户修改资料
    """

    edit_allow = getattr(settings, "EDIT_ALLOW", True)

    if not edit_allow:
        return redirect('/accounts/profile')
        
    try:
        # 获取当前用户资料
        # 不能直接使用TeamProfile.objects.filter(user=request.user.id)
        the_pro = request.user.get_profile()
    except TeamProfile.DoesNotExist:
        the_pro = TeamProfile.objects.create_default(request.user)
        
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=the_pro)
        if form.is_valid():
            form.save()                 # 更新数据
    else:
        form = ProfileForm(initial={'team_name':the_pro.team_name,
                                    'leader_name':the_pro.leader_name,
                                    'leader_sn':the_pro.leader_sn,
                                    'mem1_name':the_pro.mem1_name,
                                    'mem1_sn':the_pro.mem1_sn,
                                    'mem2_name':the_pro.mem2_name,
                                    'mem2_sn':the_pro.mem2_sn,
                                    'mem3_name':the_pro.mem3_name,
                                    'mem3_sn':the_pro.mem3_sn,
                                    'university':the_pro.university,
                                    'college':the_pro.college,
                                    })

    return render_to_response('profile/profile_edit.html',{'form':form})


@login_required
def change_password(request):
    if request.method == 'POST':
        form = ChangePasswordForm(request.POST)
        if form.is_valid():
            current_user = request.user.username
            the_user = User.objects.get(username=current_user)

            current_pass = form.cleaned_data['current_pass']
            newpass = form.cleaned_data['new_pass']
            re_newpass = form.cleaned_data['re_newpass']

            if the_user.check_password(current_pass) and newpass == re_newpass:
                the_user.set_password(newpass)
                the_user.save()         # remember to save
                return HttpResponseRedirect("/success/")
            else:
                return render_to_response("team/change_password.html", {
                    'form': form,
                    'wrong': True,
                    },context_instance=RequestContext(request))
    else:
        form = ChangePasswordForm()
    return render_to_response("team/change_password.html",
                              {'form': form,
                               },
                              context_instance=RequestContext(request))


@login_required
def challenge_choice(request):
    challenges = ChoiceChallenge.objects.all()

    return render_to_response('challenge/choice.html',
                              {'challenges':challenges},
                              context_instance=RequestContext(request))


@login_required
def challenge(request):
    challenges = Challenge.objects.filter(is_shown=True)

    has_choice = ChoiceChallenge.objects.exists()

    data = paginator(request, challenges, settings.CHALL_PER_PAGE)

    data['has_choice'] = has_choice

    return render_to_response('challenge/index.html',
                              data,
                              context_instance=RequestContext(request))



@login_required
def challenge_detail(request,challenge_id):
    challenge = get_object_or_404(Challenge, id=challenge_id)

    prev_passed = True
    if not challenge.has_passed_prev(request.user):
        prev_passed = False
        
    return render_to_response('challenge/detail.html',
                              {'challenge':challenge,
                               'prev_passed':prev_passed,
                               },context_instance=RequestContext(request))


@login_required
def submit_answer(request,challenge_id):
    challenge = get_object_or_404(Challenge, id=challenge_id)

    if not challenge.has_passed_prev(request.user):
        raise Http404
    message_level = "submit"            # 首次提交

    form = SubmitForm()
    
    if request.method == 'POST':
        submit_closed = getattr(settings, "SUBMIT_CLOSED", False)
        if submit_closed:
            message_level = "submit_closed"
        else:
            form = SubmitForm(request.POST)
            if form.is_valid():
                your_answer = form.cleaned_data['answer']
                if challenge.is_right_answer(your_answer):
                    if SubmitLog.objects.has_not_submited(request.user.id, challenge_id):
                        message_level = "right" # 正确

                        # 更新积分
                        profile = request.user.get_profile()
                        profile.finished_a_challenge(challenge.score, challenge_id)

                        # 保存日志
                        log = SubmitLog()
                        log.user=request.user
                        log.challenge=challenge
                        log.ip = request.META['REMOTE_ADDR'] # 客户端的IP地址
                        log.save()
                    else:
                        message_level = "submited" # 提交过了的答案
                else:
                    message_level = "wrong"     # 答案错误


    return render_to_response('challenge/submit.html',
                              {'message_level':message_level,
                               'form':form},
                              context_instance=RequestContext(request))

def rank(request):
    profiles = TeamProfile.objects.all().order_by('-rank','last_submit')

    return render_to_response('rank/rank.html',
                              paginator(request, profiles, settings.RANK_PER_PAGE),
                              context_instance=RequestContext(request)
                              )

def rank_report(request):
    response = HttpResponse(mimetype='text/csv')
    response['Content-Disposition'] = 'attachment; filename=%s-report.txt' % datetime.date(datetime.now())

    users = User.objects.all()
    t = loader.get_template('rank/report_template.txt')
    c = Context({
        'users': users,
        })
    response.write(t.render(c))

    return response
