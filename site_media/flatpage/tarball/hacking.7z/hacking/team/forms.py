#!/usr/bin/env python
#-*- coding:utf-8 -*-

from django import forms
from team.models import TeamProfile
from django.forms import ModelForm
from captcha.fields import CaptchaField
from django.core.exceptions import ValidationError

# for change password
class ChangePasswordForm(forms.Form):
    current_pass = forms.CharField(widget=forms.PasswordInput)
    new_pass = forms.CharField(widget=forms.PasswordInput)
    re_newpass = forms.CharField(widget=forms.PasswordInput)


class ProfileForm(ModelForm):
    class Meta:
        model = TeamProfile
        exclude = ('user', 'rank','finished' ,'activation_key')     # 不让用户更改这两个


class SubmitForm(forms.Form):
    answer = forms.RegexField(regex=r'^[\w!@#\%\$\^&\*\(\)\-\+=\?]+$',
                              label="答案", max_length=64,
                              error_message="答案不合法！只能包含  [abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_!@#$%^&*()-=+?]  (不含外层方括号)")
    captcha = CaptchaField()


    # def clean_answer(self):
    #     """
    #     Validate that the answer is validation
    #     """
    #     try:
    #         user = User.objects.get(username__iexact=self.cleaned_data['username'])
    #     except User.DoesNotExist:
    #         return self.cleaned_data['username']
    #     raise forms.ValidationError("A user with that username already exists.")


# # for feedback
# class AddFeedbackForm(forms.Form):
# #     def __init__(self, valid=None, *args, **kwargs):
# #        super(AddFeedbackForm, self).__init__(*args, **kwargs)
# #        self._valid = valid

# #     # To validate the pic code
# #     def validate_code(self,value):
# #         vali = self._valid
# #         if value != vali:
# #             raise ValidationError(u'%s is not an even number' % value)

#     def validate_code(value):
#         pass
    
#     title = forms.CharField(label='Title',
#                             widget=forms.TextInput(attrs={'size':30, 'max_length':30}))
#     content = forms.CharField(label='Content',
#                               widget=forms.Textarea(attrs={'size':1000}))

#     vali_code = forms.CharField(label='Validate Code',
#                                 widget=forms.TextInput(attrs={'size':4, 'max_length':4}),
#                                 validators=[validate_code])
