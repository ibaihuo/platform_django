#!/usr/bin/env python
#-*- coding:utf-8 -*-

from django.contrib import admin
from team.models import ChoiceChallenge,Challenge,Notice,Person,Trophy,TeamProfile, SubmitLog,Pic,Tarball,Conf

class TeamProfileAdmin(admin.ModelAdmin):
    ordering = ('-rank',)
    actions = ['activate_users', 'resend_activation_email']
    list_display=('user','team_name','rank','finished','leader_name','leader_sn','university', 'college','activation_key','activation_key_expired')
    search_fields = ('user__username', 'user__first_name')

    def activate_users(self, request, queryset):
        """
        Activates the selected users, if they are not alrady activated.
        """
        for profile in queryset:
            TeamProfile.objects.activate_user(profile.activation_key)
    activate_users.short_description = "Activate users"

    def resend_activation_email(self, request, queryset):
        """
        Re-sends activation emails for the selected users.

        Note that this will *only* send activation emails for users
        who are eligible to activate; emails will not be sent to users
        whose activation keys have expired or who have already activated.
        """
        if Site._meta.installed:
            site = Site.objects.get_current()
        else:
            site = RequestSite(request)

        for profile in queryset:
            if not profile.activation_key_expired():
                profile.send_activation_email(site)

    resend_activation_email.short_description = "Re-send activation emails"

class ConfAdmin(admin.ModelAdmin):
    list_display=('name','conf_name', 'value','desc')


class NoticeAdmin(admin.ModelAdmin):
    ordering = ('-pub_date',)
    list_display=('title','id', 'author','is_shown', 'content', 'pub_date', 'emg_level')

class PersonAdmin(admin.ModelAdmin):
    list_display=('name','rp', 'grade','advantages','brief','pic')

class ChallengeAdmin(admin.ModelAdmin):
    ordering = ('-datetime',)
    fieldsets = (
        ('Person Info',{
            'fields':('prev','person')
            }),
        ('Challenge Info', {
            'fields':('is_shown','author','score','answer','description','difficulty_level','url','url_bak')
            }),
        )
    list_display=('id','person','score','is_shown','difficulty_level','answer','author','prev','url','url_bak','datetime','description')

class SubmitLogAdmin(admin.ModelAdmin):
    list_display = ('challenge','user','ip','time',)

class TrophyAdmin(admin.ModelAdmin):
    list_display=('name', 'grade','classify','brief','pic')


admin.site.register(Pic)
admin.site.register(Tarball)
admin.site.register(ChoiceChallenge)
admin.site.register(TeamProfile, TeamProfileAdmin)
admin.site.register(Conf, ConfAdmin)
admin.site.register(Person, PersonAdmin)
admin.site.register(Notice, NoticeAdmin)
admin.site.register(Challenge, ChallengeAdmin)
admin.site.register(SubmitLog, SubmitLogAdmin)
admin.site.register(Trophy, TrophyAdmin)
