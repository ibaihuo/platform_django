#!/usr/bin/env python
#-*- coding:utf-8 -*-

import datetime
import random
import re

from django.contrib.auth.models import User
from django.db import models
from django.db import transaction
from django.utils.hashcompat import sha_constructor


class LogManager(models.Manager):
    '''日志管理类
    '''
    def has_not_submited(self, user_id, challenge_id):
        """If the user has not successful submited the challenge ,Return True
        """
        # 查无记录
        return not self.filter(user=user_id, challenge=challenge_id)


SHA1_RE = re.compile('^[a-f0-9]{40}$')

class TeamManager(models.Manager):
    """
    """
    def create_default(self, user):
        """Just to create a default TeamProfile for root or administrators
        """
        return self.create(user=user,
                           team_name=u"攻防团队",
                           leader_name=u"renewjoy",
                           leader_sn="2007122048",
                           university="CUIT",
                           college="Network Engieering",
                           activation_key=self.model.ACTIVATED,
                           )

    def activate_user(self, activation_key):
        """
        """
        # Make sure the key we're trying conforms to the pattern of a
        # SHA1 hash; if it doesn't, no point trying to look it up in
        # the database.
        if SHA1_RE.search(activation_key):
            try:
                profile = self.get(activation_key=activation_key)
            except self.model.DoesNotExist:
                return False
            if not profile.activation_key_expired():
                user = profile.user
                user.is_active = True
                user.save()
                profile.activation_key = self.model.ACTIVATED
                profile.save()
                return user
        return False
    
    def create_inactive_user(self, username, email, password, site, send_email=False):
        """
        """
        new_user = User.objects.create_user(username, email, password)
        new_user.is_active = False
        new_user.save()

        team_profile = self.create_profile(new_user)

        if send_email:
            team_profile.send_activation_email(site)

        return new_user

    # 应用了事务
    create_inactive_user = transaction.commit_on_success(create_inactive_user)

    def create_profile(self, user):
        """
        Create a ``TeamProfile`` for a given ``User``, and return the ``TeamProfile``.
        """
        salt = sha_constructor(str(random.random())).hexdigest()[:5]
        username = user.username
        if isinstance(username, unicode):
            username = username.encode('utf-8')
        activation_key = sha_constructor(salt+username).hexdigest()

        return self.create(user=user,
                           activation_key=activation_key)
        
    def delete_expired_users(self):
        """
        """
        for profile in self.all():
            if profile.activation_key_expired():
                user = profile.user
                if not user.is_active:
                    user.delete()
