#!/usr/bin/env python
#-*- coding:utf-8 -*-

form django.core.exceptions import ValidationError

def answer_validate(answer):
    pass
