#!/usr/bin/env python
#-*- coding:utf-8 -*-

from team.models import Conf

# 分页信息
try:
    NOTICE_PER_PAGE = int(Conf.objects.get(conf_name='NOTICE_PER_PAGE').value)
except:
    NOTICE_PER_PAGE = 5


try:
    RANK_PER_PAGE = int(Conf.objects.get(conf_name='RANK_PER_PAGE').value)
except:
    RANK_PER_PAGE = 3

try:
    CHALL_PER_PAGE = int(Conf.objects.get(conf_name='CHALL_PER_PAGE').value)
except:
    CHALL_PER_PAGE = 3


try:
    ACCOUNT_ACTIVATION_DAYS = int(Conf.objects.get(conf_name='ACCOUNT_ACTIVATION_DAYS').value)
except:
    ACCOUNT_ACTIVATION_DAYS = 3

try:
    REGISTRATION_OPEN = Conf.objects.get(conf_name='REGISTRATION_OPEN').value
except:
    REGISTRATION_OPEN = 'no'

if  REGISTRATION_OPEN == 'yes':
     REGISTRATION_OPEN = True
else:
     REGISTRATION_OPEN = False



#print NOTICE_PER_PAGE
