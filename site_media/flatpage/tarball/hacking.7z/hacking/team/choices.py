#!/usr/bin/env python
#-*- coding:utf-8 -*-

notices = u"挑战公告 注意事项 发奖事项 其它"

NOTICES_CLASSIFY = []

for n in notices.split(' '):
    NOTICES_CLASSIFY.append((n,n))

NOTICES_CLASSIFY = tuple(NOTICES_CLASSIFY)

#print NOTICE_CLASSIFY

ANSWER_CHOICE = (
    ('A','A'),
    ('B','B'),
    ('C','C'),
    ('D','D'),
    ('E','E'),
    ('F','F'),
    ('G','G'),
    ('H','H'),
    )

RP = (
    (u'正派',u'正派'),
    (u'亦正亦斜',u'亦正亦斜'),
    (u'恶人',u'恶人'),
    )

SCORE_CHOICE = (
    (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),
    )


CLASSIFY = (
    (1,'刀'),(2,'剑'),(3,'棍'),(4,'绝学'),(5,'丹药'),
    )

UNIVERSITY = u"成都信息工程学院 外界Hacker"

COLLEGE = u"网络工程学院 计算机学院 软件工程学院 大气科学学院 资源环境学院 电子工程学院（大气探测学院） 通信工程学院 控制工程学院 管理学院 数学学院 光电技术学院 外国语学院 政治学院 文化艺术学院 统计学院 商学院 软件与服务外包学院 继续教育学院 银杏学院 网络商学院 其它学院"

#print UNIVERSITY.split(' ')

UNIVERSITY_CHOICE = []
for u in UNIVERSITY.split(' '):
    UNIVERSITY_CHOICE.append((u,u))

UNIVERSITY_CHOICE = tuple(UNIVERSITY_CHOICE)
#print UNIVERSITY_CHOICE
COLLEGE_CHOICE = []

for c in COLLEGE.split(' '):
    COLLEGE_CHOICE.append((c,c))
COLLEGE_CHOICE = tuple(COLLEGE_CHOICE)
#print COLLEGE_CHICE
