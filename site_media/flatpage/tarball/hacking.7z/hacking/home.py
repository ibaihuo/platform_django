#!/usr/bin/env python
#-*- coding:utf-8 -*-

from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required

from django.template import RequestContext

import datetime
from django.shortcuts import render_to_response,get_object_or_404
from contactme import ContactForm
from django.core.mail import send_mail

def contactme(request):
    if request.method == 'POST': # If the form has been submitted...
        form = ContactForm(request.POST) # A form bound to the POST data
        if form.is_valid(): # All validation rules pass
            name = form.cleaned_data['name']
            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            sender = form.cleaned_data['sender']
            cc_myself = form.cleaned_data['cc_myself']

            # a greet info.
            greet = "Hi, Admin of hacking, my name is %s, I have a question:" % name
            message = greet + message

            recipients = ['oyea9le@gmail.com']
            if cc_myself:
                recipients.append(sender)

            send_mail(subject, message, sender, recipients)
            return HttpResponseRedirect('/thanks/') # Redirect after POST
    else:
        form = ContactForm() # An unbound form
    return render_to_response('home/contact.html', {'form': form,},context_instance=RequestContext(request))
